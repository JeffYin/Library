package es.isigma.dao.hibernate;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.hamcrest.CoreMatchers;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import es.isigma.dao.BaseDaoTestCase;
import es.isigma.model.PaginatedList;
import es.isigma.model.PaginatedList.SortOrder;
import es.isigma.model.User;

public class PaginatedDaoHibernateTest extends BaseDaoTestCase {
    private static final int PAGE_SIZE_2 = 2;
    private static final int PAGE_SIZE_3 = 3;
    @Autowired
    SessionFactory sessionFactory;
    private PaginatedDaoHibernate<User, Long> dao;

    @Before
    public void setUp() throws Exception {
        dao = new PaginatedDaoHibernate<User, Long>(User.class);
        dao.setSessionFactory(sessionFactory);
    }

    @Test
    public void testGetPaginatedListByQueryNamedParams() {
        String qryString = "from User u where u.address.city = :city";
        String countQryStr = "select count(*) from User u where u.address.city = :city";

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);
        LinkedHashMap<String, String> qryParams = new LinkedHashMap<String, String>();
        qryParams.put("city", "Denver");

        dao.getListByQuery(thePage, qryString, countQryStr, qryParams);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        assertThat(thePage.getList().get(0), notNullValue());
        assertThat(thePage.getList().get(0), CoreMatchers.instanceOf(User.class));
    }

    @Test
    public void testGetPaginatedListByQueryNullNamedParams() {
        String qryString = "from User u where u.address.city = 'Denver'";
        String countQryStr = "select count(*) from User u where u.address.city = 'Denver'";

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);

        dao.getListByQuery(thePage, qryString, countQryStr, (LinkedHashMap<String, String>)null);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        assertThat(thePage.getList().get(0), notNullValue());
        assertThat(thePage.getList().get(0), CoreMatchers.instanceOf(User.class));
    }

    @Test
    public void testGetPaginatedListByQueryPositionalParams() {
        String qryString = "from User u where u.address.city = ?";
        String countQryStr = "select count(*) from User u where u.address.city = ?";

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);
        ArrayList<Object> qryParams = new ArrayList<Object>();
        qryParams.add("Denver");

        dao.getListByQuery(thePage, qryString, countQryStr, qryParams);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        assertThat(thePage.getList().get(0), notNullValue());
        assertThat(thePage.getList().get(0), CoreMatchers.instanceOf(User.class));
    }

    @Test
    public void testGetPaginatedListByQueryNullPositionalParams() {
        String qryString = "from User u where u.address.city = 'Denver'";
        String countQryStr = "select count(*) from User u where u.address.city = 'Denver'";

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);

        dao.getListByQuery(thePage, qryString, countQryStr, (ArrayList<Object>)null);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        assertThat(thePage.getList().get(0), notNullValue());
        assertThat(thePage.getList().get(0), CoreMatchers.instanceOf(User.class));
    }

    @Test
    public void testGetAllPaginated() {
        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_3);
        dao.getAll(thePage );
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
    }

    @Test
    public void testGetAllPaginatedSortedDesc() {
        PaginatedList<User> thePage = getAllSorted(SortOrder.DESCENDING);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
        assertThat(thePage.getList().get(0).getUsername(), is("user3"));
    }

    @Test
    public void testGetAllPaginatedSortedAsc() {
        PaginatedList<User> thePage = getAllSorted(SortOrder.ASCENDING);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
        assertThat(thePage.getList().get(0).getUsername(), is("admin"));
    }

    private PaginatedList<User> getAllSorted(SortOrder order) {
        PaginatedDaoHibernate<User, Long> dao = new PaginatedDaoHibernate<User, Long>(User.class);
        dao.setSessionFactory(sessionFactory);
        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_3);
        thePage.setSortDir(order);
        thePage.setSortCriterion("username");
        dao.getAll(thePage);
        return thePage;
    }
}
