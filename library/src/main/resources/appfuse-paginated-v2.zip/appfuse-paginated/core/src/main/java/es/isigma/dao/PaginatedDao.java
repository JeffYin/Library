package es.isigma.dao;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;

import es.isigma.model.PaginatedList;
import es.isigma.model.User;


/**
/** <code>PaginatedDao</code> provides basic methods for pagination.
 * @author jgarcia
 *
 * @param <T>
 * @param <PK>
 */
public interface PaginatedDao<T, PK extends Serializable> extends GenericDao<T, PK> {

    /**
     * Get all objects of a type in a paginated way. Pagination params extracted from thePage
     * @param (i/o) thePage
     * @return the asked page
     */
    PaginatedList<T> getAll(PaginatedList<T> thePage);

    /**
     * Get all objects of a type owned by a user, in a paginated way.
     * @param owner
     * @param (i/o) thePage
     * @return
     */
    PaginatedList<T> getAll(User owner, PaginatedList<T> thePage);

    /**
     * Get the Rows based on the Query with a Map of Params, key is the Param Name.
     * @param thePage <code>PaginatedList<T></code> instance containing the desired page parameters.
     * @param query the HQL Query String.
     * @param countQuery the HQL Query String to count the total num of records.
     * @param params the Named Parameters.
     * @return <code>PaginatedList<T></code> instance.
     */
    PaginatedList<T> getListByQuery(PaginatedList<T> thePage, String query, String countQuery, LinkedHashMap<String, String> qryParams);

    /** Get the Rows based on the Query with a list of Params.
     * @param thePage <code>PaginatedList<T></code> instance containing the desired page parameters.
     * @param query the HQL Query String.
     * @param countQuery the HQL Query String to count the total num of records.
     * @param params the positional query parameters.
     * @return <code>PaginatedList<T></code> instance.
     */
    PaginatedList<T> getListByQuery(PaginatedList<T> thePage, String query, String countQuery, List<Object> params);

}
