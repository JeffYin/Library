package es.isigma.dao.hibernate;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import es.isigma.dao.PaginatedDao;
import es.isigma.model.PaginatedList;
import es.isigma.model.PaginatedList.SortOrder;
import es.isigma.model.User;
import es.isigma.util.OwnedUtil;


public class PaginatedDaoHibernate<T, PK extends Serializable> extends GenericDaoHibernate<T, PK> implements PaginatedDao<T, PK> {

    public PaginatedDaoHibernate(Class<T> persistentClass) {
        super(persistentClass);
    }

    /**
     * {@inheritDoc}
     */
    public PaginatedList<T> getAll(PaginatedList<T> thePage) {
    	return getAllByCriteria(null, thePage);
    }

    /**
     * {@inheritDoc}
     */
    public PaginatedList<T> getAll(User owner, PaginatedList<T> thePage) {
        OwnedUtil.verifyIsOwned(persistentClass);
        return getAllByCriteria(owner, thePage);
    }

    private PaginatedList<T> getAllByCriteria(User owner, PaginatedList<T> thePage) {
        Session session = getSessionFactory().getCurrentSession();
        // obtain all instances of a class belonging to owner:
        Criteria criteria = session.createCriteria(super.persistentClass);
        if (owner != null) {
        	criteria.add(Restrictions.eq("owner", owner));
        }
        // let's see how many instances are in total:
        criteria.setProjection(Projections.rowCount());
        Long count = (Long) criteria.uniqueResult();
        thePage.setTotalListSize(count.intValue());
        // set criteria back to obtaining entities
        criteria.setProjection(null);
        criteria.setResultTransformer(Criteria.ROOT_ENTITY);

        if (thePage.getSortCriterion() != null) {
            Order order;
            if (thePage.getSortDir() == SortOrder.ASCENDING) {
                order = Order.asc(thePage.getSortCriterion());
            } else {
                order = Order.desc(thePage.getSortCriterion());
            }
            criteria.addOrder(order);
        }
        criteria.setFirstResult(thePage.getFirstRecordIndex());
        criteria.setMaxResults(thePage.getPageSize());
        thePage.setList(criteria.list());
        return thePage;
    }
    /**
     * {@inheritDoc}
     * @param countQryStr
     */
    public PaginatedList<T> getListByQuery(
            PaginatedList<T> thePage, String qry,
            String countQry, LinkedHashMap<String, String> qryParams) {
        Session session = getSessionFactory().getCurrentSession();
        Query query = session.createQuery(qry).setFirstResult(thePage.getFirstRecordIndex()).setMaxResults(thePage.getPageSize());
        if (qryParams != null) {
        	query.setProperties(qryParams);
        }
        thePage.setList(query.list());
        thePage.setTotalListSize(getTotalCountOfRowsByQuery(countQry, qryParams));
        return thePage;
    }

    /**
     * {@inheritDoc}
     */
    public PaginatedList<T> getListByQuery(
            PaginatedList<T> thePage, String queryStr, String countQry,
            List<Object> params) {
        Session session = getSessionFactory().getCurrentSession();
        if (thePage.getSortCriterion() != null){
            if (thePage.getSortDir().equals(SortOrder.ASCENDING)){
                queryStr = queryStr.concat(" order by " + Order.asc(thePage.getSortCriterion()).toString());
            }
            if (thePage.getSortDir().equals(SortOrder.DESCENDING)){
                queryStr = queryStr.concat(" order by " + Order.desc(thePage.getSortCriterion()).toString());
            }
        }
        Query query = session.createQuery(queryStr)
                .setFirstResult(thePage.getFirstRecordIndex()).setMaxResults(thePage.getPageSize());
        setParameters(query, params);
        thePage.setList(query.list());
        thePage.setTotalListSize(getTotalCountOfRowsByQuery(countQry, params));
        return thePage;
    }

    /**
     * Get the Total number of Rows by executing a count query.
     * @param countQueryString the HQL count Query String.
     * @param params the positional parameters
     * @return the total number rows fetched by the query.
     */
    private long getTotalCountOfRowsByQuery(String countQueryString, List<Object> params) {
        Session session = getSessionFactory().getCurrentSession();
        Query query = session.createQuery(countQueryString);
        setParameters(query, params);
        Long longValue = (Long) query.uniqueResult();
        return longValue;
    }

    /**
     * Get the Total number of Rows by executing a count query.
     * @param countQueryString the HQL count Query String.
     * @param params the Named parameters
     * @return the total number rows fetched by the query.
     */
    private long getTotalCountOfRowsByQuery(String countQueryString, LinkedHashMap<String, String> params) {
        Session session = getSessionFactory().getCurrentSession();
        Query query = session.createQuery(countQueryString);
        setParameters(query, params);
        Long longValue = (Long) query.uniqueResult();
        return longValue;
    }

    private void setParameters(Query query, LinkedHashMap<String, String> params) {
        if (params != null) {
            Iterator<Entry<String, String>> it = params.entrySet().iterator();
            while (it.hasNext()) {
                Entry<String, String> pair = it.next();
                query.setParameter(pair.getKey(), pair.getValue());
            }
        }
    }

    /**
     * Setting parameters from a list.
     * @param query the <code>org.hibernate.Query</code> instance.
     * @param params the Params.
     * @return the <code>org.hibernate.Query</code> instance with parameters bounded.
     */
    private Query setParameters(Query query, List<Object> params) {
        if (params != null) {
            Iterator<Object> iter = params.iterator();
            int position = 0;
            while (iter.hasNext()) {
                Object param = iter.next();
                query.setParameter(position, param);
                position++;
            }
        }
        return query;
    }
}
