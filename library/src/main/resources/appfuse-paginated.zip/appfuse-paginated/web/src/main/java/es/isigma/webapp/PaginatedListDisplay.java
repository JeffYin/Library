package es.isigma.webapp;

import javax.servlet.http.HttpServletRequest;

import org.displaytag.properties.SortOrderEnum;

import es.isigma.model.PaginatedList;

public class PaginatedListDisplay<T> extends PaginatedList<T> implements org.displaytag.pagination.PaginatedList {

	private String searchId;

	public PaginatedListDisplay(String tableId, HttpServletRequest request, int pageSize) {
        this.setPageSize(pageSize);
        this.setSortCriterion(request.getParameter("d-" + tableId + "-s"));
        String sortDir = request.getParameter("d-" + tableId + "-o");
        setSortDirection(PaginatedList.Parameters.DESC.equals(sortDir)? SortOrderEnum.DESCENDING : SortOrderEnum.ASCENDING);
        String page = request.getParameter("d-" + tableId + "-p");
        this.setIndex(page == null ? 0 : Integer.parseInt(page) - 1);
    }

    public PaginatedListDisplay(HttpServletRequest request, int pageSize) {
		createPaginatedList(request, pageSize);
    }

    public PaginatedListDisplay(HttpServletRequest request) {
    	createPaginatedList(request, null);
    }

	private void createPaginatedList(HttpServletRequest request, Integer pageSize) {
		if (pageSize != null) {
			this.setPageSize(pageSize);
		}
        this.setSortCriterion(request.getParameter(PaginatedList.Parameters.SORT));
        String sortDir = request.getParameter(PaginatedList.Parameters.DIRECTION);
        setSortDirection(PaginatedList.Parameters.DESC.equals(sortDir)? SortOrderEnum.DESCENDING : SortOrderEnum.ASCENDING);
        String page = request.getParameter(PaginatedList.Parameters.PAGE);
        this.setIndex(page == null ? 0 : Integer.parseInt(page) - 1);
	}


    /**
     * displaytag
     */
	public int getObjectsPerPage() {
		return this.getPageSize();
	}

    /**
     * displaytag
     */
	public int getFullListSize() {
		return (int)this.getTotalListSize();
	}


    /**
     * displaytag
     */
	public SortOrderEnum getSortDirection() {
		SortOrder sortDirection = this.getSortDir();
		switch (sortDirection) {
		case DESCENDING:
			return SortOrderEnum.DESCENDING;
		case ASCENDING:
		default:
			return SortOrderEnum.ASCENDING;
		}
	}

    /**
     * displaytag
     */
	public String getSearchId() {
		return searchId;
	}

    private void setSortDirection(SortOrderEnum sortOrder) {
    	SortOrder pagSortOrder = SortOrder.ASCENDING;
    	if (sortOrder.equals(SortOrderEnum.ASCENDING)) {
    		pagSortOrder = SortOrder.ASCENDING;
    	} else if (sortOrder.equals(SortOrderEnum.DESCENDING)) {
    		pagSortOrder = SortOrder.DESCENDING;
    	}
    	this.setSortDir(pagSortOrder);
	}
}
