package es.isigma.dao.hibernate;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import es.isigma.dao.BaseDaoTestCase;
import es.isigma.model.PaginatedList;
import es.isigma.model.User;
import es.isigma.model.PaginatedList.SortOrder;

public class PaginatedDaoHibernateTest extends BaseDaoTestCase {
    private static final int PAGE_SIZE = 3;
	@Autowired
    SessionFactory sessionFactory;

    @Test
    public void testGetAllPaginated() {
    	PaginatedDaoHibernate<User, Long> dao = new PaginatedDaoHibernate<User, Long>(User.class);
    	dao.setSessionFactory(sessionFactory);
    	PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE);
		dao.getAllPaginated(thePage );
		assertThat(thePage.getTotalListSize(), is(4L));
    	assertThat(thePage.getPageNumber(), is(1));
    	assertThat(thePage.getList().size(), is(PAGE_SIZE));
    }

    @Test
    public void testGetAllPaginatedSortedDesc() {
    	PaginatedList<User> thePage = getAllSorted(SortOrder.DESCENDING);
		assertThat(thePage.getTotalListSize(), is(4L));
    	assertThat(thePage.getPageNumber(), is(1));
    	assertThat(thePage.getList().size(), is(PAGE_SIZE));
    	assertThat(thePage.getList().get(0).getUsername(), is("user3"));    	
    }

    @Test
    public void testGetAllPaginatedSortedAsc() {
    	PaginatedList<User> thePage = getAllSorted(SortOrder.ASCENDING);
		assertThat(thePage.getTotalListSize(), is(4L));
    	assertThat(thePage.getPageNumber(), is(1));
    	assertThat(thePage.getList().size(), is(PAGE_SIZE));
    	assertThat(thePage.getList().get(0).getUsername(), is("admin"));
    }

    private PaginatedList<User> getAllSorted(SortOrder order) {
    	PaginatedDaoHibernate<User, Long> dao = new PaginatedDaoHibernate<User, Long>(User.class);
    	dao.setSessionFactory(sessionFactory);
    	PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE);
    	thePage.setSortDir(order);
    	thePage.setSortCriterion("username");
		dao.getAllPaginated(thePage);
		return thePage;
    }
}
