package es.jogaco.commons.dao;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.annotation.ExpectedException;
import org.springframework.test.annotation.NotTransactional;

import es.jogaco.commons.Constants;
import es.jogaco.commons.model.Address;
import es.jogaco.commons.model.PaginatedList;
import es.jogaco.commons.model.Role;
import es.jogaco.commons.model.User;


public class UserDaoTest extends BaseDaoTestCase {
    private static final int PAGE_SIZE = 3;
    @Autowired
    private UserDao dao;
    @Autowired
    private RoleDao rdao;


    @Test
    @ExpectedException(DataAccessException.class)
    public void testGetUserInvalid() throws Exception {
        // should throw DataAccessException
        dao.get(1000L);
    }


    @Test
    public void testGetUser() throws Exception {
        User user = dao.get(-1L);

        assertNotNull(user);
        assertEquals(1, user.getRoles().size());
        assertTrue(user.isEnabled());
    }


    @Test
    public void testGetUserPassword() throws Exception {
        User user = dao.get(-1L);
        String password = dao.getUserPassword(user.getUsername());
        assertNotNull(password);
        log.debug("password: " + password);
    }


    @Test
    @NotTransactional
    @ExpectedException(DataIntegrityViolationException.class)
    public void testUpdateUser() throws Exception {
        User user = dao.get(-1L);

        Address address = user.getAddress();
        address.setAddress("new address");

        dao.saveUser(user);
        flush();

        user = dao.get(-1L);
        assertEquals(address, user.getAddress());
        assertEquals("new address", user.getAddress().getAddress());

        // verify that violation occurs when adding new user with same username
        user.setId(null);

        // should throw DataIntegrityViolationException
        dao.saveUser(user);
    }


    @Test
    public void testAddUserRole() throws Exception {
        User user = dao.get(-1L);
        assertEquals(1, user.getRoles().size());

        Role role = rdao.getRoleByName(Constants.ADMIN_ROLE);
        user.addRole(role);
        dao.saveUser(user);
        flush();

        user = dao.get(-1L);
        assertEquals(2, user.getRoles().size());

        // add the same role twice - should result in no additional role
        user.addRole(role);
        dao.saveUser(user);
        flush();

        user = dao.get(-1L);
        assertEquals("more than 2 roles", 2, user.getRoles().size());

        user.getRoles().remove(role);
        dao.saveUser(user);
        flush();

        user = dao.get(-1L);
        assertEquals(1, user.getRoles().size());
    }


    @Test
    @ExpectedException(DataAccessException.class)
    public void testAddAndRemoveUser() throws Exception {
        User user = new User("testuser");
        user.setPassword("testpass");
        user.setFirstName("Test");
        user.setLastName("Last");
        Address address = new Address();
        address.setCity("Denver");
        address.setProvince("CO");
        address.setCountry("USA");
        address.setPostalCode("80210");
        user.setAddress(address);
        user.setEmail("testuser@appfuse.org");

        Role role = rdao.getRoleByName(Constants.USER_ROLE);
        assertNotNull(role.getId());
        user.addRole(role);

        user = dao.saveUser(user);
        flush();

        assertNotNull(user.getId());
        user = dao.get(user.getId());
        assertEquals("testpass", user.getPassword());

        dao.remove(user.getId());
        flush();

        // should throw DataAccessException
        dao.get(user.getId());
    }


    @Test
    public void testUserExists() throws Exception {
        boolean b = dao.exists(-1L);
        assertTrue(b);
    }


    @Test
    public void testUserNotExists() throws Exception {
        boolean b = dao.exists(111L);
        assertFalse(b);
    }


    @Test
    public void testPaginatedUserList() throws Exception {
        PaginatedList<User> thePage = new PaginatedList<User>();
        thePage.setPageSize(PAGE_SIZE);
        ArrayList<Object> params = new ArrayList<Object>();
        dao.getUsers(thePage);
        assertNotNull(thePage);
        assertThat(thePage.getList().size(), is(PAGE_SIZE));

        // get second page
        thePage.setIndex(1);
        dao.getUsers(thePage);
        assertNotNull(thePage);
        assertThat(thePage.getList().size(), is(1));
    }


    @Test
    public void testSearch() throws Exception {
        // reindexAll all the data
        dao.reindex();
        List<User> found = dao.search("*");
        assertEquals(4, found.size());

        found = dao.search("Denver");
        assertEquals(3, found.size());
    }

    // @Test
    // public void testUserSearch() throws Exception {
    // // reindexAll all the data
    // compassGps.index();
    //
    // User user = compassTemplate.get(User.class, -2);
    // assertNotNull(user);
    // assertEquals("Matt", user.getFirstName());
    //
    // compassTemplate.execute(new CompassCallbackWithoutResult() {
    // @Override
    // protected void doInCompassWithoutResult(CompassSession compassSession) throws CompassException {
    // CompassHits hits = compassSession.find("Matt");
    // assertEquals(1, hits.length());
    // assertEquals("Matt", ((User) hits.data(0)).getFirstName());
    // assertEquals("Matt", hits.resource(0).getValue("firstName"));
    // }
    // });
    //
    // // test mirroring
    // user = dao.get(-2L);
    // user.setFirstName("MattX");
    // dao.saveUser(user);
    // flush();
    //
    // // now verify it is reflected in the index
    // user = compassTemplate.get(User.class, -2);
    // assertNotNull(user);
    // assertEquals("MattX", user.getFirstName());
    //
    // compassTemplate.execute(new CompassCallbackWithoutResult() {
    // @Override
    // protected void doInCompassWithoutResult(CompassSession compassSession) throws CompassException {
    // CompassHits hits = compassSession.find("MattX");
    // assertEquals(1, hits.length());
    // assertEquals("MattX", ((User) hits.data(0)).getFirstName());
    // }
    // });
    // }
}
