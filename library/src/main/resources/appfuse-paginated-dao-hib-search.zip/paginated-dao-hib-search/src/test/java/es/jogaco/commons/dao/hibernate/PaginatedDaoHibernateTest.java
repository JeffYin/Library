package es.jogaco.commons.dao.hibernate;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.apache.lucene.queryParser.ParseException;
import org.hamcrest.CoreMatchers;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import es.jogaco.commons.Constants;
import es.jogaco.commons.dao.BaseDaoTestCase;
import es.jogaco.commons.dao.RoleDao;
import es.jogaco.commons.model.Document;
import es.jogaco.commons.model.PaginatedList;
import es.jogaco.commons.model.PaginatedList.SortOrder;
import es.jogaco.commons.model.Role;
import es.jogaco.commons.model.User;
import es.jogaco.commons.service.DateFilter;
import es.jogaco.commons.util.DateUtil;
import java.util.Date;
import java.util.HashMap;

public class PaginatedDaoHibernateTest extends BaseDaoTestCase {
    private static final int PAGE_SIZE_2 = 2;
    private static final int PAGE_SIZE_3 = 3;
    private static final int PAGE_SIZE_1 = 1;
    @Autowired
    SessionFactory sessionFactory;
    private PaginatedDaoHibernate<User, Long> userDao;
    private PaginatedDaoHibernate<Document, Long> documentDao;
    @Autowired
    private RoleDao rdao;

    @Before
    public void setUp() throws Exception {
        userDao = new PaginatedDaoHibernate<User, Long>(User.class);
        userDao.setSessionFactory(sessionFactory);
        documentDao = new PaginatedDaoHibernate<Document, Long>(Document.class);
        documentDao.setSessionFactory(sessionFactory);
    }

    @Test
    public void testGetPaginatedListByQueryNamedParams() {
        String qryString = "from User u where u.address.city = :city";
        String countQryStr = "select count(*) " + qryString;

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);
        LinkedHashMap<String, String> qryParams = new LinkedHashMap<String, String>();
        qryParams.put("city", "Denver");

        userDao.getListByQuery(thePage, qryString, countQryStr, qryParams);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        assertThat(thePage.getList().get(0), notNullValue());
        assertThat(thePage.getList().get(0), CoreMatchers.instanceOf(User.class));
    }

    @Test
    public void testGetPaginatedListByQueryNullNamedParams() {
        String qryString = "from User u where u.address.city = 'Denver'";
        String countQryStr = "select count(*) " + qryString;

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);

        userDao.getListByQuery(thePage, qryString, countQryStr, (LinkedHashMap<String, String>)null);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        assertThat(thePage.getList().get(0), notNullValue());
        assertThat(thePage.getList().get(0), CoreMatchers.instanceOf(User.class));
    }

    @Test
    public void testGetPaginatedListByQueryPositionalParams() {
        String qryString = "from User u where u.address.city = ?";
        String countQryStr = "select count(*) " + qryString;

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);
        ArrayList<Object> qryParams = new ArrayList<Object>();
        qryParams.add("Denver");

        userDao.getListByQuery(thePage, qryString, countQryStr, qryParams, null);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        assertThat(thePage.getList().get(0), notNullValue());
        assertThat(thePage.getList().get(0), CoreMatchers.instanceOf(User.class));
    }

    @Test
    public void testGetPaginatedListByQueryNullPositionalParams() {
        String qryString = "from User u where u.address.city = 'Denver'";
        String countQryStr = "select count(*) " + qryString;

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);

        userDao.getListByQuery(thePage, qryString, countQryStr, (ArrayList<Object>)null, null);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        assertThat(thePage.getList().get(0), notNullValue());
        assertThat(thePage.getList().get(0), CoreMatchers.instanceOf(User.class));
    }


    @Test
    public void testGetPaginatedListByQueryBetweenDates() throws Exception {
        User user = userDao.get(-1L);
        String qryString = "from Document d where d.owner = ?";
        String countQryStr = "select count(*) " + qryString;
        ArrayList<Object> params = new ArrayList<Object>(1);
        params.add(user);

        Date dateFrom = DateUtil.convertStringToDate("09/01/2011"); // MM/dd/yyyy
        Date dateTo = DateUtil.convertStringToDate("10/30/2011"); // MM/dd/yyyy
        DateFilter filter = new DateFilter("d.date", dateFrom, dateTo);

        PaginatedList<User> thePage = new PaginatedList<User>();

        userDao.getListByQuery(thePage, qryString, countQryStr, params, filter);
        assertThat(thePage.getTotalListSize(), is(2L));
        assertThat(thePage.getList().size(), is(2));
        assertThat(thePage.getList().get(0), notNullValue());
    }

    @Test
    public void testGetAllPaginated() {
        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_3);
        userDao.getAll(null, thePage );
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
    }

    @Test
    public void testGetAllPaginatedSortedDesc() {
        PaginatedList<User> thePage = getAllSorted(SortOrder.DESCENDING);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
        assertThat(thePage.getList().get(0).getUsername(), is("user3"));
    }

    @Test
    public void testGetAllPaginatedSortedAsc() {
        PaginatedList<User> thePage = getAllSorted(SortOrder.ASCENDING);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getPageNumber(), is(1));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
        assertThat(thePage.getList().get(0).getUsername(), is("admin"));
    }


    @Test
    public void testGetAllPaginatedDistinct() {
        // Let's have at least one user with two roles.
        // The list of all entities should not have duplicates because of several roles:
        User user = userDao.get(-1L);
        Role role = rdao.getRoleByName(Constants.ADMIN_ROLE);
        assertNotNull(role.getId());
        user.addRole(role);
        userDao.save(user);
        flush();

        PaginatedList<User> thePage = new PaginatedList<User>(1000); // get all
        thePage.setSortCriterion("username");
        userDao.getAll(null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getList().size(), is(4));
    }


    @Test
    public void testSearchByWildcardAll() throws ParseException {
        userDao.reindex();
        flushSearchIndexes();

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_3);
        // get first page:
        userDao.search("*", thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
        // get second page:
        thePage.setIndex(1);
        userDao.search("*", thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(1));
    }

    @Test
    public void testSearchByTerm() throws ParseException {
        userDao.reindex();
        flushSearchIndexes();

        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);
        // get first page:
        userDao.search("Raible", thePage);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        // get second page:
        thePage.setIndex(1);
        userDao.search("Raible", thePage);
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(1));
    }


    @Test
    public void testGetAllPaginatedSortedByTwoAttributes() {
        PaginatedDaoHibernate<User, Long> dao = new PaginatedDaoHibernate<User, Long>(User.class);
        dao.setSessionFactory(sessionFactory);
        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_3);
        thePage.setSortDir(SortOrder.ASCENDING);
        thePage.setSortCriterion("firstName,lastName");
        dao.getAll(null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getList().get(0).getFullName(), is("Charles Smith"));

        thePage.setSortDir(SortOrder.DESCENDING);
        thePage.setSortCriterion("firstName,lastName");
        dao.getAll(null, thePage);
        assertThat(thePage.getList().get(0).getFullName(), is("Tomcat User"));

    }

    @Test
    public void testGetAllPaginatedSortedByAttributeFromRelation() {
        PaginatedDaoHibernate<Document, Long> dao = new PaginatedDaoHibernate<Document, Long>(Document.class);
        dao.setSessionFactory(sessionFactory);
        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        thePage.setSortDir(SortOrder.ASCENDING);
        thePage.setSortCriterion("owner.firstName");
        dao.getAll(null, thePage);
        assertThat(thePage.getTotalListSize(), is(6L));
    }

    @Test
    public void testGetAllPaginatedSortedByTwoAttributesOneOfThemRelation() {
        PaginatedDaoHibernate<Document, Long> dao = new PaginatedDaoHibernate<Document, Long>(Document.class);
        dao.setSessionFactory(sessionFactory);
        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        thePage.setSortDir(SortOrder.ASCENDING);
        thePage.setSortCriterion("title,owner.firstName");
        dao.getAll(null, thePage);
        assertThat(thePage.getTotalListSize(), is(6L));
        assertThat(thePage.getList().get(0).getTitle(), is("another one"));
        assertThat(thePage.getList().get(0).getOwner().getFirstName(), is("Matt"));
    }

    @Test
    public void testGetAllPaginatedSortedByTwoAttributesFromRelation() {
        PaginatedDaoHibernate<Document, Long> dao = new PaginatedDaoHibernate<Document, Long>(Document.class);
        dao.setSessionFactory(sessionFactory);
        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        thePage.setSortDir(SortOrder.ASCENDING);
        thePage.setSortCriterion("owner.lastName,owner.firstName");
        dao.getAll(null, thePage);
        assertThat(thePage.getTotalListSize(), is(6L));
        assertThat(thePage.getList().get(0).getOwner().getLastName(), is("Raible"));
        assertThat(thePage.getList().get(0).getOwner().getFirstName(), is("John"));
    }

    @Test
    public void testGetAllPaginatedFilteredFrom() throws java.text.ParseException {
        PaginatedDaoHibernate<Document, Long> dao = new PaginatedDaoHibernate<Document, Long>(Document.class);
        dao.setSessionFactory(sessionFactory);
        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        thePage.setSortDir(SortOrder.ASCENDING);
        thePage.setSortCriterion("date");
        Date dateFrom = DateUtil.convertStringToDate("10/01/2011"); // MM/dd/yyyy
        DateFilter filter = new DateFilter("date", dateFrom, null);
        dao.getAll(filter, thePage);
        assertThat(thePage.getTotalListSize(), is(2L));
    }

    @Test
    public void testGetAllPaginatedFilteredTo() throws java.text.ParseException {
        PaginatedDaoHibernate<Document, Long> dao = new PaginatedDaoHibernate<Document, Long>(Document.class);
        dao.setSessionFactory(sessionFactory);
        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        thePage.setSortDir(SortOrder.ASCENDING);
        thePage.setSortCriterion("date");
        Date dateTo = DateUtil.convertStringToDate("09/01/2011"); // MM/dd/yyyy
        DateFilter filter = new DateFilter("date", null, dateTo);
        dao.getAll(filter, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
    }

    @Test
    public void testGetAllPaginatedFilteredFromTo() throws java.text.ParseException {
        PaginatedDaoHibernate<Document, Long> dao = new PaginatedDaoHibernate<Document, Long>(Document.class);
        dao.setSessionFactory(sessionFactory);
        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        thePage.setSortDir(SortOrder.ASCENDING);
        thePage.setSortCriterion("date");
        Date dateTo = DateUtil.convertStringToDate("09/01/2011"); // MM/dd/yyyy
        DateFilter filter = new DateFilter("date", null, dateTo);
        dao.getAll(filter, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
    }

    @Test
    public void testSearchOwnedByWildcardAll() throws ParseException {
        userDao.reindexAll(false);
        flushSearchIndexes();

        User user = userDao.get(-1L);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        // get first page:
        documentDao.search(user, "*", null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
        // get second page:
        thePage.setIndex(1);
        documentDao.search(user, "*", null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(1));
    }


    @Test
    public void testSearchFilteredByWildcardAll() throws ParseException {
        userDao.reindexAll(false);
        flushSearchIndexes();

        User user = userDao.get(-1L);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        // get first page, filtered by owner:
        HashMap<String, String> filter = new HashMap<String, String>();
        filter.put("owner.id", user.getId().toString());
        documentDao.search("*", filter, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
        // get next page, filtered by owner:
        thePage.setIndex(1);
        documentDao.search("*", filter, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(1));
    }


    @Test
    public void testSearchMultifilteredByWildcardAll() throws ParseException {
        userDao.reindexAll(false);
        flushSearchIndexes();

        User user = userDao.get(-1L);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        // get first page, filtered by owner, enabled:
        HashMap<String, String> filter = new HashMap<String, String>();
        filter.put("owner.id", user.getId().toString());
        filter.put("enabled", "true");

        documentDao.search("*", filter, thePage);
        assertThat(thePage.getTotalListSize(), is(2L));
    }


    @Test
    public void testSearchOwnedByTerm() throws ParseException {
        userDao.reindexAll(false);
        flushSearchIndexes();

        User user = userDao.get(-1L);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_1);
        // get first page:
        documentDao.search(user, "title", null, thePage);
        assertThat(thePage.getTotalListSize(), is(2L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_1));
        // get second page:
        thePage.setIndex(1);
        documentDao.search(user, "title", null, thePage);
        assertThat(thePage.getTotalListSize(), is(2L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(1));
    }


    @Test
    public void testSearchOwnedByTermFilteredFrom() throws ParseException, java.text.ParseException {
        userDao.reindexAll(false);
        documentDao.reindexAll(false);
        flushSearchIndexes();

        User user = userDao.get(-1L);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_1);
        Date dateFrom = DateUtil.convertStringToDate("10/01/2011"); // MM/dd/yyyy

        DateFilter filter = new DateFilter("date", dateFrom, null);

        // get first page:
        documentDao.search(user, "title", filter, thePage);
        assertThat(thePage.getTotalListSize(), is(1L));
    }

    @Test
    public void testSearchOwnedByTermFilteredTo() throws ParseException, java.text.ParseException {
        userDao.reindexAll(false);
        documentDao.reindexAll(false);
        flushSearchIndexes();

        User user = userDao.get(-1L);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_1);
        Date dateTo = DateUtil.convertStringToDate("09/01/2011"); // MM/dd/yyyy

        DateFilter filter = new DateFilter("date", null, dateTo);

        // get first page:
        documentDao.search(user, "title", filter, thePage);
        assertThat(thePage.getTotalListSize(), is(1L));
    }

    @Test
    public void testSearchOwnedByTermFilteredFromTo() throws ParseException, java.text.ParseException {
        userDao.reindexAll(false);
        documentDao.reindexAll(false);
        flushSearchIndexes();

        User user = userDao.get(-1L);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_1);
        Date dateFrom = DateUtil.convertStringToDate("09/01/2011"); // MM/dd/yyyy
        Date dateTo = DateUtil.convertStringToDate("10/01/2011"); // MM/dd/yyyy

        DateFilter filter = new DateFilter("date", dateFrom, dateTo);

        // get first page:
        documentDao.search(user, "title", filter, thePage);
        assertThat(thePage.getTotalListSize(), is(2L));
    }

    private PaginatedList<User> getAllSorted(SortOrder order) {
        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_3);
        thePage.setSortDir(order);
        thePage.setSortCriterion("username");
        userDao.getAll(null, thePage);
        return thePage;
    }
}
