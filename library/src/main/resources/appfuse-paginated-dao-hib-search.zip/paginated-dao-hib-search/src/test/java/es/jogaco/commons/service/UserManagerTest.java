package es.jogaco.commons.service;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import es.jogaco.commons.Constants;
import es.jogaco.commons.model.PaginatedList;
import es.jogaco.commons.model.User;


public class UserManagerTest extends BaseManagerTestCase {
    private static final int PAGE_SIZE = 2;
    private Log log = LogFactory.getLog(UserManagerTest.class);
    @Autowired
    private UserManager mgr;
    @Autowired
    private RoleManager roleManager;
    private User user;


    @Test
    public void testGetUser() throws Exception {
        user = mgr.getUserByUsername("user");
        assertNotNull(user);

        log.debug(user);
        assertEquals(1, user.getRoles().size());
    }


    @Test
    public void testSaveUser() throws Exception {
        user = mgr.getUserByUsername("user");
        user.setPhoneNumber("303-555-1212");

        log.debug("saving user with updated phone number: " + user);

        user = mgr.saveUser(user);
        assertEquals("303-555-1212", user.getPhoneNumber());
        assertEquals(1, user.getRoles().size());
    }


    @Test
    public void testAddAndRemoveUser() throws Exception {
        user = new User();

        // call populate method in super class to populate test data
        // from a properties file matching this class name
        user = (User) populate(user);

        user.addRole(roleManager.getRole(Constants.USER_ROLE));

        user = mgr.saveUser(user);
        assertEquals("john", user.getUsername());
        assertEquals(1, user.getRoles().size());

        log.debug("removing user...");

        mgr.removeUser(user.getId().toString());

        try {
            user = mgr.getUserByUsername("john");
            fail("Expected 'Exception' not thrown");
        } catch (Exception e) {
            log.debug(e);
            assertNotNull(e);
        }
    }


    @Test
    public void testUserSearch() throws Exception {
        // reindexAll already existing database records
        mgr.reindexAll(false);

        log.debug("searching user...");
        List<User> result = mgr.search("Matt");
        log.debug("found: " + result.size());
        assertThat(result.size(), is(1));
    }


    @Test
    public void testUserSearchPaginated() throws Exception {
        // reindexAll already existing database records
        mgr.reindexAll(false);
        List<User> result = mgr.search("*");
        assertThat(result.size(), is(4));

        log.debug("searching user paginated...");
        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE);
        thePage = mgr.search("Denver", thePage);

        log.debug("found: " + thePage.getList().size());
        assertThat(thePage.getList().size(), is(PAGE_SIZE));
        User foundUser = thePage.getList().get(0);
        assertThat(foundUser.getAddress().getCity(), containsString("Denver"));
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getTotalPages(), is(2));

        // get second page
        thePage.setIndex(1);
        mgr.search("Denver", thePage);
        log.debug("found: " + thePage.getList().size());
        assertThat(thePage.getList().size(), is(1));
        foundUser = thePage.getList().get(0);
        assertThat(foundUser.getAddress().getCity(), containsString("Denver"));
        assertThat(thePage.getTotalListSize(), is(3L));
        assertThat(thePage.getTotalPages(), is(2));
    }
}
