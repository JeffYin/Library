package es.jogaco.commons.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.queryParser.ParseException;

import es.jogaco.commons.dao.GenericDao;
import es.jogaco.commons.dao.hibernate.GenericDaoHibernate;
import es.jogaco.commons.model.Document;
import es.jogaco.commons.model.User;

import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

public class GenericDaoTest extends BaseDaoTestCase {
    Log log = LogFactory.getLog(GenericDaoTest.class);
    GenericDao<User, Long> userDao;
    GenericDao<Document, Long> documentDao;
    @Autowired
    SessionFactory sessionFactory;

    @Before
    public void setUp() {
        userDao = new GenericDaoHibernate<User, Long>(User.class, sessionFactory);
        documentDao = new GenericDaoHibernate<Document, Long>(Document.class, sessionFactory);
    }

    @Test
    public void getUser() {
        User user = userDao.get(-1L);
        assertNotNull(user);
        assertEquals("user", user.getUsername());
    }

    @Test
    public void searchAllByWildcard() throws ParseException {
        userDao.reindex();
        flushSearchIndexes();

        List<User> found = userDao.search("*");
        assertThat(found.size(), is(4));
    }

    @Test
    public void searchByTerm() throws ParseException {
        userDao.reindex();
        flushSearchIndexes();

        List<User> found = userDao.search("Raible");
        assertThat(found.size(), is(3));
    }

    @Test
    public void searchOwnedAllByWildcard() throws ParseException {
        documentDao.reindex();
        flushSearchIndexes();

        User user = userDao.get(-1L);
        List<Document> found = documentDao.search(user, "*");
        assertThat(found.size(), is(4));
        Document document = found.get(0);
        assertThat(document.getOwner(), is(user));

        user = userDao.get(-2L);
        found = documentDao.search(user, "*");
        assertThat(found.size(), is(1));
        document = found.get(0);
        assertThat(document.getOwner(), is(user));
    }

    @Test
    public void searchOwnedByTerm() throws ParseException {
        documentDao.reindex();
        flushSearchIndexes();

        User user = userDao.get(-1L);
        List<Document> found = documentDao.search(user, "title");
        assertThat(found.size(), is(2));
        Document document = found.get(0);
        assertThat(document.getOwner(), is(user));
    }
}
