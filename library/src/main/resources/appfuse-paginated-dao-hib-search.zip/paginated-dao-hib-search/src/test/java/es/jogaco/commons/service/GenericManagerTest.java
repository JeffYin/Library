package es.jogaco.commons.service;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.queryParser.ParseException;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import es.jogaco.commons.dao.UserDao;
import es.jogaco.commons.dao.hibernate.PaginatedDaoHibernate;
import es.jogaco.commons.model.Document;
import es.jogaco.commons.model.PaginatedList;
import es.jogaco.commons.model.User;
import es.jogaco.commons.service.impl.GenericManagerImpl;


public class GenericManagerTest extends BaseManagerTestCase {
    private static final int PAGE_SIZE_2 = 2;
    private static final int PAGE_SIZE_3 = 3;
    private static final int PAGE_SIZE_1 = 1;
    private Log log = LogFactory.getLog(GenericManagerTest.class);

    @Autowired
    UserDao userDao;
    @Autowired
    SessionFactory sessionFactory;
    PaginatedDaoHibernate<Document, Long> docDao;
    private GenericManager<Document, Long> docManager;
    private GenericManager<User, Long> userMgr;

    @Before
    public void setUp() {
        docDao = new PaginatedDaoHibernate<Document, Long>(Document.class);
        docDao.setSessionFactory(sessionFactory);
        docManager = new GenericManagerImpl<Document, Long>(docDao);
        userMgr = new GenericManagerImpl<User, Long>(userDao);

        docManager.reindexAll(false);
        flushSearchIndexes(sessionFactory);
    }

    @Test
    public void testPaginatedSearchOwnedByTerm() throws Exception {
        User user = userMgr.get(-1L);
        assertNotNull(user);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_1);
        // get first page:
        docManager.search(user, "title", null, thePage);
        assertThat(thePage.getTotalListSize(), is(2L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_1));
        // get second page:
        thePage.setIndex(1);
        docManager.search(user, "title", null, thePage);
        assertThat(thePage.getTotalListSize(), is(2L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(1));
    }

    @Test
    public void testPaginatedSearchOwnedByWildcardAll() throws ParseException {
        User user = userMgr.get(-1L);
        assertNotNull(user);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_3);
        // get first page:
        docManager.search(user, "*", null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_3));
        // get second page:
        thePage.setIndex(1);
        docManager.search(user, "*", null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(1));
    }

    @Test
    public void testPaginatedSearchOwnedByTermEmpty() throws Exception {
        User user = userMgr.get(-1L);
        assertNotNull(user);

        PaginatedList<Document> thePage = new PaginatedList<Document>(PAGE_SIZE_2);
        // get first page:
        docManager.search(user, "", null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        // get second page:
        thePage.setIndex(1);
        docManager.search(user, "", null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(2));
        // get second page with null:
        docManager.search(user, null, null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(2));
    }

    @Test
    public void testSearchOwnedByTermEmpty() throws Exception {
        User user = userMgr.get(-1L);
        assertNotNull(user);

        // get with empty:
        List<Document> found = docManager.search(user, "");
        assertThat(found.size(), is(4));
        // get with null:
        found = docManager.search(user, null);
        assertThat(found.size(), is(4));
    }

    @Test
    public void testPaginatedSearchByTermEmpty() throws Exception {
        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);
        // get first page:
        userMgr.search("", (DateFilter)null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
        // get second page with null:
        thePage.setIndex(1);
        userMgr.search(null, (DateFilter)null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(2));
    }

    @Test
    public void testSearchByTermEmpty() throws Exception {
        // get with empty:
        List<User> found = userMgr.search("");
        assertThat(found.size(), is(4));
        // get with null:
        found = userMgr.search(null);
        assertThat(found.size(), is(4));
    }

    @Test
    public void testGetAll() throws Exception {
        List<User> found = userMgr.getAll();
        assertThat(found.size(), is(4));
    }

    @Test
    public void testGetAllPaginated() throws Exception {
        PaginatedList<User> thePage = new PaginatedList<User>(PAGE_SIZE_2);
        userMgr.getAll(null, thePage);
        assertThat(thePage.getTotalListSize(), is(4L));
        assertThat(thePage.getTotalPages(), is(2));
        assertThat(thePage.getList().size(), is(PAGE_SIZE_2));
    }

}
