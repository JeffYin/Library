package es.jogaco.commons.service.impl;

import java.util.List;

import javax.jws.WebService;

import org.apache.lucene.queryParser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import es.jogaco.commons.dao.UserDao;
import es.jogaco.commons.model.PaginatedList;
import es.jogaco.commons.model.User;
import es.jogaco.commons.service.DateFilter;
import es.jogaco.commons.service.UserCredentialsRenewException;
import es.jogaco.commons.service.UserExistsException;
import es.jogaco.commons.service.UserManager;
import es.jogaco.commons.service.UserService;


/**
 * Implementation of UserManager interface.
 *
 * @author <a href="mailto:matt@raibledesigns.com">Matt Raible</a>
 */
@Service("userManager")
@WebService(serviceName = "UserService", endpointInterface = "es.jogaco.commons.service.UserService")
public class UserManagerImpl extends GenericManagerImpl<User, Long> implements UserManager, UserService {
    private PasswordEncoder passwordEncoder;
    private UserDao userDao;


    @Autowired
    public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }


    @Autowired
    public void setUserDao(UserDao userDao) {
        this.dao = userDao;
        this.userDao = userDao;
    }


    /**
     * {@inheritDoc}
     */
    public User getUser(Long userId) {
        return userDao.get(userId);
    }


    /**
     * {@inheritDoc}
     */
    public User getUser(String userId) {
        return userDao.get(new Long(userId));
    }


    /**
     * {@inheritDoc}
     */
    public List<User> getUsers() {
        return userDao.getAllDistinct();
    }


    /**
     * {@inheritDoc}
     */
    public User saveUser(User user) throws UserExistsException {

        if (user.getVersion() == null) {
            // if new user, lowercase userId
            user.setUsername(user.getUsername().toLowerCase());
        }

        // Get and prepare password management-related artifacts
        boolean passwordChanged = false;
        if (passwordEncoder != null) {
            // Check whether we have to encrypt (or re-encrypt) the password
            if (user.getVersion() == null) {
                // New user, always encrypt
                passwordChanged = true;
            } else {
                // Existing user, check password in DB
                String currentPassword = userDao.getUserPassword(user.getUsername());
                if (currentPassword == null) {
                    passwordChanged = true;
                } else {
                    if (!currentPassword.equals(user.getPassword())) {
                        passwordChanged = true;
                    }
                }
            }

            // If password was changed (or new user), encrypt it
            if (passwordChanged) {
                user.setPassword(passwordEncoder.encodePassword(user.getPassword(), null));
            }
        } else {
            log.warn("PasswordEncoder not set, skipping password encryption...");
        }

        try {
            return userDao.saveUser(user);
        } catch (DataIntegrityViolationException e) {
            // e.printStackTrace();
            log.warn(e.getMessage());
            throw new UserExistsException("User '" + user.getUsername() + "' already exists!");
        } catch (JpaSystemException e) { // needed for JPA
            // e.printStackTrace();
            log.warn(e.getMessage());
            throw new UserExistsException("User '" + user.getUsername() + "' already exists!");
        }
    }


    /**
     * {@inheritDoc}
     */
    public void removeUser(String userId) {
        log.debug("removing user: " + userId);
        userDao.remove(new Long(userId));
    }


    /**
     * {@inheritDoc}
     *
     * @param username
     *            the login name of the human
     * @return User the populated user object
     * @throws UsernameNotFoundException
     *             thrown when username not found
     */
    public User getUserByUsername(String username) throws UsernameNotFoundException {
        return (User) userDao.loadUserByUsername(username);
    }


    /**
     * {@inheritDoc}
     *
     * @throws ParseException
     */
    public List<User> search(String searchTerm) throws ParseException {
        return super.search(searchTerm);
    }


    /*
     * (non-Javadoc)
     *
     * @see es.jogaco.commons.service.UserManager#getUsers(es.jogaco.commons.model.PaginatedList)
     */
    public void getUsers(PaginatedList<User> thePage) {
        userDao.getUsers(thePage);
    }


    public PaginatedList<User> search(String searchTerm, PaginatedList<User> thePage) throws ParseException {
        return super.search(searchTerm, (DateFilter)null, thePage);
    }


    public User saveNewCredentials(User user, String suppliedOldPassword, String newPassword)
            throws UserCredentialsRenewException, UserExistsException {
        if (!checkPassword(user, suppliedOldPassword)) {
            throw new UserCredentialsRenewException();
        }
        user.setPassword(newPassword);
        user.setCredentialsExpired(false);
        return saveUser(user);
    }


    public boolean checkPassword(User user, String suppliedPassword) {
        String password = user.getPassword();
        if (passwordEncoder != null) {
            suppliedPassword = passwordEncoder.encodePassword(suppliedPassword, null);
        }
        if (!password.equals(suppliedPassword)) {
            return false;
        } else {
            return true;
        }
    }
}
