package es.jogaco.commons.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.queryParser.ParseException;

import es.jogaco.commons.dao.PaginatedDao;
import es.jogaco.commons.model.PaginatedList;
import es.jogaco.commons.model.User;
import es.jogaco.commons.service.GenericManager;
import es.jogaco.commons.service.DateFilter;
import java.util.Map;


/**
 * This class serves as the Base class for all other Managers - namely to hold common CRUD methods that they
 * might all use. You should only need to extend this class when your require custom CRUD logic.
 * <p/>
 * <p>
 * To register this class in your Spring context file, use the following XML.
 *
 * <pre>
 *     &lt;bean id="userManager" class="es.jogaco.commons.service.impl.GenericManagerImpl"&gt;
 *         &lt;constructor-arg&gt;
 *             &lt;bean class="es.jogaco.commons.dao.hibernate.GenericDaoHibernate"&gt;
 *                 &lt;constructor-arg value="es.jogaco.commons.model.User"/&gt;
 *                 &lt;property name="sessionFactory" ref="sessionFactory"/&gt;
 *             &lt;/bean&gt;
 *         &lt;/constructor-arg&gt;
 *     &lt;/bean&gt;
 * </pre>
 * <p/>
 * <p>
 * If you're using iBATIS instead of Hibernate, use:
 *
 * <pre>
 *     &lt;bean id="userManager" class="es.jogaco.commons.service.impl.GenericManagerImpl"&gt;
 *         &lt;constructor-arg&gt;
 *             &lt;bean class="es.jogaco.commons.dao.ibatis.GenericDaoiBatis"&gt;
 *                 &lt;constructor-arg value="es.jogaco.commons.model.User"/&gt;
 *                 &lt;property name="dataSource" ref="dataSource"/&gt;
 *                 &lt;property name="sqlMapClient" ref="sqlMapClient"/&gt;
 *             &lt;/bean&gt;
 *         &lt;/constructor-arg&gt;
 *     &lt;/bean&gt;
 * </pre>
 *
 * @param <T>
 *            a type variable
 * @param <PK>
 *            the primary key for that type
 * @author <a href="mailto:matt@raibledesigns.com">Matt Raible</a>
 */
public class GenericManagerImpl<T, PK extends Serializable> implements GenericManager<T, PK> {
    /**
     * Log variable for all child classes. Uses LogFactory.getLog(getClass()) from Commons Logging
     */
    protected static final Log log = LogFactory.getLog(GenericManagerImpl.class);

    /**
     * GenericDao instance, set by constructor of child classes
     */
    protected PaginatedDao<T, PK> dao;


    public GenericManagerImpl() {
    }


    public GenericManagerImpl(PaginatedDao<T, PK> genericDao) {
        this.dao = genericDao;
    }


    /**
     * {@inheritDoc}
     */
    public List<T> getAll() {
        return dao.getAll();
    }


    public PaginatedList<T> getAll(DateFilter filter, PaginatedList<T> thePage) {
        return dao.getAll(filter, thePage);
    }


    public PaginatedList<T> getAll(User owner, DateFilter filter, PaginatedList<T> thePage) {
        return dao.getAll(owner, filter, thePage);
    }


    /**
     * {@inheritDoc}
     */
    public T get(PK id) {
        return dao.get(id);
    }


    /**
     * {@inheritDoc}
     */
    public boolean exists(PK id) {
        return dao.exists(id);
    }


    /**
     * {@inheritDoc}
     */
    public T save(T object) {
        return dao.save(object);
    }


    /**
     * {@inheritDoc}
     */
    public void remove(PK id) {
        dao.remove(id);
    }


    /*
     * (non-Javadoc)
     *
     * @see es.jogaco.commons.service.GenericManager#search(es.jogaco.commons.model.User, java.lang.String,
     * java.lang.Class)
     */
    @SuppressWarnings("unchecked")
    public List<T> search(User owner, String q) throws ParseException {
        if (q == null || "".equals(q.trim())) {
            return dao.getAll(owner);
        }
        return dao.search(owner, q);
    }


    /*
     * (non-Javadoc)
     *
     * @see es.jogaco.commons.service.GenericManager#search(es.jogaco.commons.model.User, java.lang.String,
     * java.lang.Class, es.jogaco.commons.model.PaginatedList)
     */
    public PaginatedList<T> search(User owner, String q, DateFilter filter, PaginatedList<T> thePage) throws ParseException {
        if (q == null || "".equals(q.trim())) {
            return dao.getAll(owner, filter, thePage);
        }
        return dao.search(owner, q, filter, thePage);
    }

    /*
     * (non-Javadoc)
     *
     * @see es.jogaco.commons.service.GenericManager#search(java.lang.String, java.lang.Class,
     * es.jogaco.commons.model.PaginatedList)
     */
    public PaginatedList<T> search(String q, DateFilter filter, PaginatedList<T> thePage) throws ParseException {
        if (q == null || "".equals(q.trim())) {
            return getAll(filter, thePage);
        }
        return dao.search(q, filter, thePage);
    }

    /* (non-Javadoc)
     * @see es.jogaco.commons.service.GenericManager#search(java.lang.String, java.util.Map es.jogaco.commons.model.PaginatedList)
     */
    public PaginatedList<T> search(String q, Map<String, String> filter, PaginatedList<T> thePage) throws ParseException {
        if (q == null || "".equals(q.trim())) {
            return getAll(null, thePage);
        }
        return dao.search(q, filter, thePage);
    }


    /*
     * (non-Javadoc)
     *
     * @see es.jogaco.commons.service.GenericManager#search(java.lang.String, java.lang.Class)
     */
    @SuppressWarnings("unchecked")
    public List<T> search(String q) throws ParseException {
        if (q == null || "".equals(q.trim())) {
            return getAll();
        }
        return dao.search(q);
    }


    /*
     * (non-Javadoc)
     *
     * @see es.jogaco.commons.service.GenericManager#reindexAll(java.lang.Class)
     */
    public void reindex() {
        dao.reindex();
    }


    public void reindexAll(boolean async) {
        dao.reindexAll(async);
    }


    /**
     * {@inheritDoc}
     *
     * @param queryName
     * @param queryParams
     */
    public List<T> findByNamedQuery(String queryName, Map<String, Object> queryParams) {
        return (List<T>) dao.findByNamedQuery(queryName, queryParams);
    }
}
