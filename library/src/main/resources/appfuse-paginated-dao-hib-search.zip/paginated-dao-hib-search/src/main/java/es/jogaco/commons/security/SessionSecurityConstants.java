package es.jogaco.commons.security;

public class SessionSecurityConstants {
    public static final String CERTIFICATE = "certificate";
    public static final String CERTIFICATE_SUBJECT = "certificatesubject";
    // Do not rename the following literals before first checking for references in the
    // jsp and java code.
    public static final String ACCESSED_REQUEST = "accessedrequest";
    public static final String USER_FULLNAME = "userfullname";
    public static final String USER_DIGITAL_ID = "userdigitalid";
    public static final String SHOW_SECURITY_DIALOG = "showsecuritydialog";
}
