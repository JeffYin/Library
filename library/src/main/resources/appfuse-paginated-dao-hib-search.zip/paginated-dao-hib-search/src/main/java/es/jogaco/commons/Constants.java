package es.jogaco.commons;

/**
 * Constant values used throughout the application.
 * 
 * @author <a href="mailto:matt@raibledesigns.com">Matt Raible</a>
 */
public final class Constants {

    private Constants() {
        // hide me
    }

    // ~ Static fields/initializers =============================================
    /**
     * The name of the ResourceBundle used in this application
     */
    public static final String BUNDLE_CORE_KEY = "ResourcesCore";
    /**
     * File separator from System properties
     */
    public static final String FILE_SEP = System.getProperty("file.separator");

    /**
     * The name of the Administrator role, as specified in web.xml
     */
    public static final String ADMIN_ROLE = "ROLE_ADMIN";

    /**
     * The name of the User role, as specified in web.xml
     */
    public static final String USER_ROLE = "ROLE_USER";

    /**
     * The name of the Signer role for certificate logins
     */
    public static final String SIGN_CLIENT_ROLE = "ROLE_SIGN_CLIENT";

    /**
     * The name of the role which identifies payment account users
     */
    // public static final String PAYMENT_ACCOUNT_ROLE = "ROLE_PAYMENT_ACCOUNT";
    /**
     * The name of the Signer role
     */
    public static final String SIGNER_ROLE = "ROLE_SIGNER";

    /**
     * The name of the User role, as specified in web.xml
     */
    public static final String ISSUER_ROLE = "ROLE_ISSUER";

    /**
     * The name of the user's role list, a request-scoped attribute when adding/editing a user.
     */
    public static final String USER_ROLES = "userRoles";

    /**
     * The name of the available roles list, a request-scoped attribute when adding/editing a user.
     */
    public static final String AVAILABLE_ROLES = "availableRoles";
}
