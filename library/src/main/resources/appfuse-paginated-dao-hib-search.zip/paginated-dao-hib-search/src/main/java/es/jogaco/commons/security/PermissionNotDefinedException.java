package es.jogaco.commons.security;

public class PermissionNotDefinedException extends RuntimeException {

    public PermissionNotDefinedException(String msg) {
        super(msg);
    }

}
