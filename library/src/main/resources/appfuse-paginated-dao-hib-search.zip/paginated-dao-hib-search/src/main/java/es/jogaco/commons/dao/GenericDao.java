package es.jogaco.commons.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.lucene.queryParser.ParseException;

import es.jogaco.commons.model.User;


/**
 * Generic DAO (Data Access Object) with common methods to CRUD POJOs.
 *
 * <p>Extend this interface if you want typesafe (no casting necessary) DAO's for your
 * domain objects.
 *
 * @author <a href="mailto:bwnoll@gmail.com">Bryan Noll</a>
 * @param <T> a type variable
 * @param <PK> the primary key for that type
 */
public interface GenericDao <T, PK extends Serializable> {

    /**
     * Generic method used to get all objects of a particular type. This
     * is the same as lookup up all rows in a table.
     * @return List of populated objects
     */
    List<T> getAll();

    /**
     * Generic method to get all objects of a particular type that belong to a user. Must have an "owner" field.
     * @param owner
     * @return List of all objects belonging to the owner
     */
    List<T> getAll(User owner);

    /**
     * Gets all records without duplicates.
     * <p>Note that if you use this method, it is imperative that your model
     * classes correctly implement the hashcode/equals methods</p>
     * @return List of populated objects
     */
    List<T> getAllDistinct();

    /**
     * Generic method to get an object based on class and identifier. An
     * ObjectRetrievalFailureException Runtime Exception is thrown if
     * nothing is found.
     *
     * @param id the identifier (primary key) of the object to get
     * @return a populated object
     * @see org.springframework.orm.ObjectRetrievalFailureException
     */
    T get(PK id);

    /**
     * Checks for existence of an object of type T using the id arg.
     * @param id the id of the entity
     * @return - true if it exists, false if it doesn't
     */
    boolean exists(PK id);

    /**
     * Generic method to save an object - handles both update and insert.
     * @param object the object to save
     * @return the persisted object
     */
    T save(T object);

    /**
     * Generic method to delete an object based on class and id
     * @param id the identifier (primary key) of the object to remove
     */
    void remove(PK id);

    /**
     * Find a list of records by using a named query with optional named params
     * @param queryName query name of the named query
     * @param queryParams a map of the query names and the values (or null if no params)
     * @return a list of the records found
     */
    List<T> findByNamedQuery(String queryName, Map<String, Object> queryParams);

    /**
     * Find a list of records by using a named query with optional positional (?) params
     * @param queryName query name of the named query
     * @param queryParams a list of the values ordered as in the named query (or null)
     * @return a list of the records found
     */
    List<T> findByNamedQuery(String queryName, List<Object> queryParams);

    /**
     * Generic method to search for an object.
     * @param searchTerm the search term
     * @return a list of matched objects
     */
    List<T> search(String searchTerm) throws ParseException;

    /**
     * Generic method to search for an object, owned by a User.
     * @param owner the owner of the objects to search for.
     * @param searchTerm the search term
     * @return a list of matched objects
     * @see es.jogaco.commons.model.Owned
     */
    List<T> search(User owner, String searchTerm) throws ParseException;

    /**
     * Generic method to regenerate full text index of the persistentClass
     */
    void reindex();

    /**
     * Generic method to regenerate full text index of all indexed classes
     * @param async true to perform the reindexing asynchronously
     */
    void reindexAll(boolean async);

}
