package es.jogaco.commons.util;

import java.io.PrintWriter;
import java.io.Writer;

/**
 * PrintWriter wrapper, so that jsp can include servlet generated output without the error
 * "java.io.IOException: Stream closed"
 * @author jgarcia
 */
public class PrintWriterWrapper extends PrintWriter {

    /**
     * Wraps a PrintWriter
     * @param out
     */
    public PrintWriterWrapper(PrintWriter out) {
        super(out);
    }

    /**
     * Ignore close, so that jsp include dont crash with "java.io.IOException: Stream closed".
     * Servlet container will close the writer
     */
    public void close() {
        // do not close!
        // just ignore
    }
}
