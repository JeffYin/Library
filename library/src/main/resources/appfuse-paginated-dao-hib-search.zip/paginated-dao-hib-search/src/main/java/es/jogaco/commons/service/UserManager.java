package es.jogaco.commons.service;

import java.util.List;

import org.apache.lucene.queryParser.ParseException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import es.jogaco.commons.dao.UserDao;
import es.jogaco.commons.model.PaginatedList;
import es.jogaco.commons.model.User;


/**
 * Business Service Interface to handle communication between web and persistence layer.
 * 
 * @author <a href="mailto:matt@raibledesigns.com">Matt Raible</a> Modified by <a
 *         href="mailto:dan@getrolling.com">Dan Kibler </a>
 */
public interface UserManager extends GenericManager<User, Long> {
    /**
     * Convenience method for testing - allows you to mock the DAO and set it on an interface.
     * 
     * @param userDao
     *            the UserDao implementation to use
     */
    void setUserDao(UserDao userDao);


    /**
     * Retrieves a user by userId. An exception is thrown if user not found
     * 
     * @param userId
     *            the identifier for the user
     * @return User
     */
    User getUser(Long userId);


    /**
     * Retrieves a user by userId. An exception is thrown if user not found
     * 
     * @param userId
     *            the identifier for the user
     * @return User
     */
    User getUser(String userId);


    /**
     * Finds a user by their username.
     * 
     * @param username
     *            the user's username used to login
     * @return User a populated user object
     * @throws org.springframework.security.core.userdetails.UsernameNotFoundException
     *             exception thrown when user not found
     */
    User getUserByUsername(String username) throws UsernameNotFoundException;


    /**
     * Retrieves a list of all users.
     * 
     * @return List
     */
    List<User> getUsers();


    /**
     * Retrieves a paginated list of all users
     * 
     * @param thePage
     */
    void getUsers(PaginatedList<User> thePage);


    /**
     * Saves a user's information.
     * 
     * @param user
     *            the user's information
     * @throws UserExistsException
     *             thrown when user already exists
     * @return user the updated user object
     */
    User saveUser(User user) throws UserExistsException;


    /**
     * Removes a user from the database by their userId
     * 
     * @param userId
     *            the user's id
     */
    void removeUser(String userId);


    /**
     * Search a user for search terms.
     * 
     * @param searchTerm
     *            the search terms.
     * @return a list of matches, or all if no searchTerm.
     * @throws ParseException
     */
    List<User> search(String searchTerm) throws ParseException;


    /**
     * Search a user for search terms.
     * 
     * @param searchTerm
     *            the search terms.
     * @param thePage
     *            pagination params
     * @return a paginated list of matches, or all if no searchTerm.
     * @throws ParseException
     */
    PaginatedList<User> search(String searchTerm, PaginatedList<User> thePage) throws ParseException;


    /**
     * @param user
     * @param suppliedOldPassword
     * @param newPassword
     * @throws UserCredentialsRenewException
     *             if suppliedOldPassword is not coincident with current password previous to update
     * @throws UserExistsException
     */
    User saveNewCredentials(User user, String suppliedOldPassword, String newPassword)
            throws UserCredentialsRenewException, UserExistsException;


    /**
     * Checks the password of the user, used from webservice
     * 
     * @param user
     *            The user to check
     * @param suppliedPassword
     *            The access password of the user
     * @return
     */
    boolean checkPassword(User user, String suppliedPassword);
}
