package es.jogaco.commons.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;

import es.jogaco.commons.dao.UniversalDao;
import es.jogaco.commons.model.ObjectIdentity;
import es.jogaco.commons.model.Owned;


public class OwnerPermission implements Permission {
    private UniversalDao dao;

    public OwnerPermission(UniversalDao dao) {
        this.dao = dao;
    }

    public boolean isAllowed(Authentication authentication, Object targetDomainObject) {
        boolean hasPermission = false;
        if (isAuthenticated(authentication)) {
            Owned owned = null;
            if (isObjectIdentity(targetDomainObject)) {
                ObjectIdentity id = (ObjectIdentity) targetDomainObject;
                owned = (Owned) dao.get(id.getType(), id.getId());
            } else if (isOwned(targetDomainObject)) {
                owned = (Owned) targetDomainObject;
            }
            if (owned != null) {
                String login = getLogin(authentication);
                if (owned.getOwner().getUsername().equals(login)) {
                    hasPermission = true;
                }
            }
        }
        return hasPermission;
    }

    private String getLogin(Authentication authentication) {
        Object authenticationUserDetails = authentication.getPrincipal();
        return ((UserDetails) authenticationUserDetails).getUsername();
    }

    private boolean isObjectIdentity(Object targetDomainObject) {
        return targetDomainObject instanceof ObjectIdentity;
    }

    private boolean isOwned(Object targetDomainObject) {
        return targetDomainObject instanceof Owned;
    }

    private boolean isAuthenticated(Authentication authentication) {
        return authentication != null && authentication.getPrincipal() instanceof UserDetails;
    }

}
