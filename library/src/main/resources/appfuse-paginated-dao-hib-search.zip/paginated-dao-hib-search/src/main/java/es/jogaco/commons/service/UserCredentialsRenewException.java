package es.jogaco.commons.service;

public class UserCredentialsRenewException extends Exception {

}
