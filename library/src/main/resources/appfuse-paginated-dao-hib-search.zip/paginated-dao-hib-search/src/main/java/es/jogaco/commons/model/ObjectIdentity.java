package es.jogaco.commons.model;

import java.io.Serializable;

public class ObjectIdentity implements Serializable {
    /**
	 *
	 */
	private static final long serialVersionUID = 3830842558504347223L;
	private Long id;
    private Class clazz;

    public ObjectIdentity(Long id, Class clazz) {
        this.id = id;
        this.clazz = clazz;
    }
    public Long getId() {
        return id;
    }
    public Class getType() {
        return clazz;
    }
}
