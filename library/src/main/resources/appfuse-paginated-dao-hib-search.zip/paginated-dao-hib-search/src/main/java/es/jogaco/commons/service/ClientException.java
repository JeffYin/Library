package es.jogaco.commons.service;

/**
 * Root class for exceptions during execution of PortaSigma client operations.
 */
public class ClientException extends Exception {
    private static final long serialVersionUID = -4745143363706080120L;

    public ClientException(String message) {
        super(message);
    }

    public ClientException(String message, Throwable cause) {
        super(message, cause);
    }
}
