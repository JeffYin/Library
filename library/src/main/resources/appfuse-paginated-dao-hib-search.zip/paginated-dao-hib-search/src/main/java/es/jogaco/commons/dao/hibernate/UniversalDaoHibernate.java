package es.jogaco.commons.dao.hibernate;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ObjectRetrievalFailureException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import es.jogaco.commons.dao.UniversalDao;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.apache.lucene.util.Version;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.ParseException;

/**
 * This class serves as the a class that can CRUD any object witout any
 * Spring configuration. The only downside is it does require casting
 * from Object to the object class.
 *
 * @author Bryan Noll
 */
public class UniversalDaoHibernate extends HibernateDaoSupport implements UniversalDao {
    /**
     * Log variable for all child classes. Uses LogFactory.getLog(getClass()) from Commons Logging
     */
    protected final Log log = LogFactory.getLog(getClass());
    private final StandardAnalyzer defaultAnalyzer;

    UniversalDaoHibernate() {
        defaultAnalyzer = new StandardAnalyzer(Version.LUCENE_31);
    }
    /**
     * {@inheritDoc}
     */
    public Object save(Object o) {
        return getHibernateTemplate().merge(o);
    }

    /**
     * {@inheritDoc}
     */
    public Object get(Class clazz, Serializable id) {
        Object o = getHibernateTemplate().get(clazz, id);

        if (o == null) {
            throw new ObjectRetrievalFailureException(clazz, id);
        }

        return o;
    }

    /**
     * {@inheritDoc}
     */
    public List getAll(Class clazz) {
        return getHibernateTemplate().loadAll(clazz);
    }

    /**
     * {@inheritDoc}
     */
    public void remove(Class clazz, Serializable id) {
        getHibernateTemplate().delete(get(clazz, id));
    }

    public List search(Class clazz, String query) throws ParseException {
        org.hibernate.classic.Session sess = getSessionFactory().getCurrentSession();
        FullTextSession txtSession = Search.getFullTextSession(sess);

        org.apache.lucene.search.Query qry = HibernateSearchTools.generateQuery(query, clazz, sess, defaultAnalyzer);
        org.hibernate.search.FullTextQuery hibQuery = txtSession.createFullTextQuery(qry, clazz);
        return hibQuery.list();
    }

    public void reindex(Class clazz) {
        HibernateSearchTools.reindex(clazz, getSessionFactory().getCurrentSession());
    }
}
