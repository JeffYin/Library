package es.jogaco.commons.service;


/**
 * Exceptions associated to HTTP status codes that represent errors (values 40x and 500).
 * See <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html">HTTP Status Codes</a> for details.
 */
public class ClientHttpStatusException extends ClientException {
    private static final long serialVersionUID = 1L;
    int httpStatus;
    String responseText;

    public ClientHttpStatusException(int httpStatus, String responseText) {
        super(String.format(
                "HTTP error: %1$d - %2$s", httpStatus, responseText));
        this.httpStatus = httpStatus;
        this.responseText = responseText;
    }

    public int getHttpStatus() {
        return httpStatus;
    }

    public String getResponseText() {
        return responseText;
    }

}
