/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.jogaco.commons.service;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.search.TermQuery;
import org.hibernate.search.annotations.Factory;
import org.hibernate.search.annotations.Key;
import org.hibernate.search.filter.FilterKey;
import org.hibernate.search.filter.StandardFilterKey;

/**
 *
 * @author jgarcia
 */
public class OwnedFilterFactory {

    private String ownerId;

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @Factory
    public Filter buildOwnedFilter() {
        Term term = new Term("owner.id", ownerId);
        Query qry = new TermQuery(term);
        Filter filter = new QueryWrapperFilter(qry);
        return filter;
    }
    /**
     * method for hibernate search to maintain its internal filter cache
     * @return
     */
    @Key
    public FilterKey getKey() {
        StandardFilterKey key = new StandardFilterKey();
        key.addParameter(ownerId);
        return key;
    }
}
