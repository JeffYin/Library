package es.jogaco.commons.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.context.i18n.LocaleContextHolder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Date Utility Class used to convert Strings to Dates and Timestamps
 * For i18n, provide a date-time.properties resource bundle file in the classpath with entry:
 * date.format=MM/dd/yyyy
 *
 * @author <a href="mailto:matt@raibledesigns.com">Matt Raible</a>
 *         Modified by <a href="mailto:dan@getrolling.com">Dan Kibler </a>
 *         to correct time pattern. Minutes should be mm not MM (MM is month).
 */
public final class DateUtil {
    private static final String DATE_TIME_BUNDLE = "date-time";
	private static Log log = LogFactory.getLog(DateUtil.class);
    private static final String TIME_PATTERN = "HH:mm";

    /**
     * Checkstyle rule: utility classes should not have public constructor
     */
    private DateUtil() {
    }

    /**
     * Return default datePattern (MM/dd/yyyy)
     *
     * @return a string representing the date pattern on the UI
     */
    public static String getDatePattern() {
        Locale locale = LocaleContextHolder.getLocale();
        String defaultDatePattern;
        try {
            defaultDatePattern = ResourceBundle.getBundle(DATE_TIME_BUNDLE, locale)
                    .getString("date.format");
        } catch (MissingResourceException mse) {
            defaultDatePattern = "MM/dd/yyyy";
        }

        return defaultDatePattern;
    }

    public static String getDateTimePattern() {
        return DateUtil.getDatePattern() + " HH:mm:ss.S";
    }

    /**
     * This method attempts to convert an Oracle-formatted date
     * in the form dd-MMM-yyyy to mm/dd/yyyy.
     *
     * @param aDate date from database as a string
     * @return formatted string for the ui
     */
    public static String getDate(Date aDate) {
        SimpleDateFormat df;
        String returnValue = "";

        if (aDate != null) {
            df = new SimpleDateFormat(getDatePattern());
            returnValue = df.format(aDate);
        }

        return (returnValue);
    }

    /**
     * This method generates a string representation of a date/time
     * in the format you specify on input
     *
     * @param aMask the date pattern the string is in
     * @param strDate a string representation of a date
     * @return a converted Date object
     * @throws ParseException when String doesn't match the expected format
     * @see java.text.SimpleDateFormat
     */
    public static Date convertStringToDate(String aMask, String strDate)
            throws ParseException {
        SimpleDateFormat df;
        Date date;
        df = new SimpleDateFormat(aMask);

        if (log.isDebugEnabled()) {
            log.debug("converting '" + strDate + "' to date with mask '" + aMask + "'");
        }

        try {
            date = df.parse(strDate);
        } catch (ParseException pe) {
            //log.error("ParseException: " + pe);
            throw new ParseException(pe.getMessage(), pe.getErrorOffset());
        }

        return (date);
    }

    /**
     * This method returns the current date time in the format:
     * MM/dd/yyyy HH:MM a
     *
     * @param theTime the current time
     * @return the current date/time
     */
    public static String getTimeNow(Date theTime) {
        return getDateTime(TIME_PATTERN, theTime);
    }

    /**
     * This method returns the current date/time
     * @return the current date/time
     */
    public static Date getTimeNow() {
    	return Calendar.getInstance().getTime();
    }
    /**
     * This method returns the current date in the format: MM/dd/yyyy
     *
     * @return the current date
     * @throws ParseException when String doesn't match the expected format
     */
    public static Calendar getToday() throws ParseException {
        Date today = new Date();
        SimpleDateFormat df = new SimpleDateFormat(getDatePattern());

        // This seems like quite a hack (date -> string -> date),
        // but it works ;-)
        String todayAsString = df.format(today);
        Calendar cal = new GregorianCalendar();
        cal.setTime(convertStringToDate(todayAsString));

        return cal;
    }

    /**
     * This method generates a string representation of a date's date/time
     * in the format you specify on input
     *
     * @param aMask the date pattern the string is in
     * @param aDate a date object
     * @return a formatted string representation of the date
     * @see java.text.SimpleDateFormat
     */
    public static String getDateTime(String aMask, Date aDate) {
        SimpleDateFormat df = null;
        String returnValue = "";

        if (aDate == null) {
            log.warn("aDate is null!");
        } else {
            df = new SimpleDateFormat(aMask);
            returnValue = df.format(aDate);
        }

        return (returnValue);
    }

    /**
     * This method generates a string representation of a date based
     * on the System Property 'dateFormat'
     * in the format you specify on input
     *
     * @param aDate A date to convert
     * @return a string representation of the date
     */
    public static String convertDateToString(Date aDate) {
        return getDateTime(getDatePattern(), aDate);
    }

    /**
     * This method generates a string representation of a date based
     * on a format specified by param
     * in the format you specify on input
     *
     * @param aDate A date to convert
     * @return a string representation of the date
     */
    public static String convertDateToString(Date aDate, String format) {
        return getDateTime(format, aDate);
    }

    /**
     * This method converts a String to a date using the datePattern
     *
     * @param strDate the date to convert (in format MM/dd/yyyy)
     * @return a date object
     * @throws ParseException when String doesn't match the expected format
     */
    public static Date convertStringToDate(final String strDate) throws ParseException {
        Date aDate = null;

        // simple check to find out whether a time is included
        boolean hasTime = strDate.contains(":");

        try {
            String pattern = hasTime? getDateTimePattern() : getDatePattern();
            if (log.isDebugEnabled()) {
                log.debug("converting date with pattern: " + pattern);
            }
            aDate = convertStringToDate(pattern, strDate);
        } catch (ParseException pe) {
            log.error("Could not convert '" + strDate + "' to a date, throwing exception");
            //pe.printStackTrace();
            throw new ParseException(pe.getMessage(),
                    pe.getErrorOffset());
        }

        return aDate;
    }
    public static Date now() {
        return Calendar.getInstance().getTime();
    }

    public static Date nowPlus(int amount, int units) {
        Calendar cal = (Calendar)Calendar.getInstance().clone();
        cal.add(units, amount);
        return cal.getTime();
    }


    public static Date add(Date date, int units, int amount) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(units, amount);
        return cal.getTime();
    }

    public static Date addMonths(Date date, int months) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MONTH, months);
        return cal.getTime();
    }

    public static Date startOfCurrentMonth() {
        Calendar cal1 = Calendar.getInstance();
        return startOfMonth(cal1.getTime());
    }

    public static Date startOfNextMonth() {
        Calendar cal1 = Calendar.getInstance();
        return startOfNextMonth(cal1.getTime());
    }

    public static int daysToEndOfMonth() {
        Calendar cal = Calendar.getInstance();
        int today = cal.get(Calendar.DAY_OF_MONTH);
        int maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        return maxDays - today;
    }


    public static float percentageMonthLeft() {
        Date now = now();
        Date startOfNextMonth = startOfNextMonth();
        return percentageMonthElapsed(now, startOfNextMonth, true);
    }


    /**
     *
     * @param start
     * @param end
     * @param roundUp true if we want to compensate positively (e.g. when adding signatures)
     *                or false if we want to compensate negatively (e.g. when calculating price)
     * @return
     */
    public static float percentageMonthElapsed(Date start, Date end, boolean roundUp) {
        double daysLeftThisMonth = differenceInDaysBetween(start, end);
        // add compensation for time until 9h next day...
        if(roundUp)
            daysLeftThisMonth += 9.0 / 24.0;
        Calendar cal = Calendar.getInstance();
        cal.setTime(start);
        int maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        return (float)( daysLeftThisMonth / maxDays );
    }

    static final long DAY_TO_MS = 24 * 60 * 60 * 1000;

    private static double differenceInDaysBetween(Date from, Date to) {
        long diff = to.getTime() - from.getTime();
        double diffDays = (double)diff / DAY_TO_MS;
        return diffDays;
    }


    public static Date endOfMonth(Date date) {
        Calendar cal = calendarEndOfMonth(date);
        return cal.getTime();
    }

    public static Date endOfCurrentMonth() {
        return endOfMonth(now());
    }

    private static Calendar calendarEndOfMonth(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MONTH, 1);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.MILLISECOND, -1);
        return cal;
    }

    public static Date startOfNextMonth(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.MONTH, 1);
        return cal.getTime();
    }

    public static Date startOfMonth(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    // ISO 8601 date parsing ----------------------------------------------------------------------

    private static final String ISO_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";

    //      YYYY = four-digit year
    //      MM   = two-digit month (01=January, etc.)
    //      DD   = two-digit day of month (01 through 31)
    //      hh   = two digits of hour (00 through 23) (am/pm NOT allowed)
    //      mm   = two digits of minute (00 through 59)
    //      ss   = two digits of second (00 through 59)
    //      s    = one or more digits representing a decimal fraction of a second
    //      TZD  = time zone designator (Z or +hh:mm or -hh:mm)
    public static Date parseISO8601( String input ) throws java.text.ParseException {
        SimpleDateFormat df = new SimpleDateFormat( ISO_TIME_FORMAT );
        return df.parse( input );
    }

    public static String toISO8601String( Date date ) {
        SimpleDateFormat df = new SimpleDateFormat( ISO_TIME_FORMAT );
        return df.format( date );
    }

}
