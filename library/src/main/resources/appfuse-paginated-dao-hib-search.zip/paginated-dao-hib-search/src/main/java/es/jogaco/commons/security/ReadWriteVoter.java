package es.jogaco.commons.security;

import java.util.Collection;

import org.springframework.aop.framework.ReflectiveMethodInvocation;
import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;

import es.jogaco.commons.dao.UniversalDao;
import es.jogaco.commons.model.ObjectIdentity;
import es.jogaco.commons.model.Owned;
import es.jogaco.commons.model.User;

public class ReadWriteVoter implements AccessDecisionVoter {

    private String rolePrefix = "RW_";
    private UniversalDao dao;

    public void setDao(UniversalDao dao) {
        this.dao = dao;
    }

    public String getRolePrefix() {
        return rolePrefix;
    }

    public void setRolePrefix(String rolePrefix) {
        this.rolePrefix = rolePrefix;
    }

    public boolean supports(ConfigAttribute attribute) {
        if (attribute.getAttribute() != null
                && attribute.getAttribute().startsWith(getRolePrefix())) {
            return true;
        } else {
            return false;
        }
    }

    public boolean supports(Class<?> clazz) {
        return true;
    }

    public int vote(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) {
        int result = ACCESS_ABSTAIN;

        for (ConfigAttribute attribute : attributes) {
            if (this.supports(attribute)) {

                if (object instanceof ReflectiveMethodInvocation) {
                    ReflectiveMethodInvocation method = (ReflectiveMethodInvocation) object;
                    Object[] arguments = method.getArguments();
                    for (Object arg : arguments) {
                        Owned owned = null;
                        if (arg instanceof ObjectIdentity) {
                            ObjectIdentity id = (ObjectIdentity) arg;
                            owned = (Owned) dao.get(id.getType(), id.getId());
                        } else if (arg instanceof Owned) {
                            owned = (Owned) arg;
                        }
                        if (owned != null) {
                            if (owned.getOwner() == null) {
                                owned.setOwner(getLoggedInUser(authentication));
                                result = ACCESS_GRANTED;
                            } else {
                                String login = getLogin(authentication);
                                if (owned.getOwner().getUsername().equals(login)) {
                                    result = ACCESS_GRANTED;
                                } else {
                                    result = ACCESS_DENIED;
                                }
                            }
                        }
                    }
                }
            }
        }

        return result;
    }

    private String getLogin(Authentication authentication) {
        Object authenticationUserDetails = authentication.getPrincipal();
        return ((UserDetails) authenticationUserDetails).getUsername();
    }

    private User getLoggedInUser(Authentication authentication) {
        Object authenticationUserDetails = authentication.getPrincipal();
        return (User) authenticationUserDetails;
    }
}
