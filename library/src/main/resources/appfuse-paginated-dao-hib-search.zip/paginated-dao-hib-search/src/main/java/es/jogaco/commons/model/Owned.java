package es.jogaco.commons.model;


public interface Owned {

    User getOwner();
    void setOwner(User owner);

}
